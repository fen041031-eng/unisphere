from django.urls import path
from . import views
app_name = 'usauth'

urlpatterns = [
    path('login', views.uslogin, name='login'),
    path('logout', views.uslogout, name='logout'),
    path('register', views.register, name='register'),
    path('captcha', views.send_email_captcha, name='email_captcha')
]