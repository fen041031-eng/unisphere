from django.urls import path
from . import views
app_name = 'club'
urlpatterns = [
    path("approve/list/", views.approve_list, name="approve_list"),
    path("approve/<int:club_id>/", views.approve_club, name="approve_detail"),
    path('apply/', views.apply_club, name='apply_club'),
]