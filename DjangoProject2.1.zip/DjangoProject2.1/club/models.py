from django.db import models

# 严格匹配club_club表结构，且语法正确
class Club(models.Model):
    id = models.AutoField(primary_key=True)
    name = models.CharField(max_length=50)
    type = models.CharField(max_length=20)
    intro = models.TextField()
    status = models.CharField(max_length=10)
    apply_time = models.DateTimeField()
    founder_id = models.IntegerField()
    advisor = models.CharField(max_length=20)
    contact = models.CharField(max_length=20, blank=True, null=True)
    purpose = models.TextField(blank=True, null=True)
    recruit_num = models.IntegerField(blank=True, null=True)
    reject_reason = models.TextField(blank=True, null=True)

    class Meta:
        db_table = "club_club"  # 必须和数据库表名一致
        managed = False  # 不允许Django修改表结构
        app_label = 'club'  # 显式指定app_label，解决“未声明”错误