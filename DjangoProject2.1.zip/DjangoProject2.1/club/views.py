from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from .models import Club  # 现在能正确导入Club模型
from django.contrib import messages  # 新增导入
from django.utils import timezone
@login_required
def approve_list(request):
    # 筛选待审核社团（status='pending'）
    pending_clubs = Club.objects.filter(status="pending")
    return render(request, "club/approve_list.html", {"clubs": pending_clubs})

# 社团申请视图（仅普通用户可访问）
@login_required
def apply_club(request):
    # 1. 权限控制：管理员禁止申请社团
    if request.user.is_staff:
        messages.error(request, "管理员无需申请创建社团！")
        return redirect("/")
    
    # 2. 处理POST提交（用户填写表单后提交）
    if request.method == "POST":
        # 获取表单数据（和模板字段一一对应）
        name = request.POST.get("name", "").strip()
        type = request.POST.get("type", "").strip()
        intro = request.POST.get("intro", "").strip()
        advisor = request.POST.get("advisor", "").strip()
        contact = request.POST.get("contact", "").strip()
        recruit_num = request.POST.get("recruit_num", 0)
        purpose = request.POST.get("purpose", "").strip()

        # 3. 前端表单验证（必填项）
        required_fields = [name, type, intro, advisor]
        if not all(required_fields):
            messages.error(request, "社团名称、类型、介绍、指导老师为必填项！")
            return render(request, "club/apply_club.html")

        # 4. 创建待审核社团数据
        Club.objects.create(
            name=name,
            type=type,
            intro=intro,
            advisor=advisor,
            contact=contact,
            recruit_num=recruit_num if recruit_num else 0,
            purpose=purpose,
            apply_time=timezone.now(),  # 自动填充申请时间
            founder_id=request.user.id,  # 关联当前登录用户
            status="pending"  # 状态：待审核
        )

        # 5. 提交成功提示
        messages.success(request, f"社团「{name}」申请已提交！请等待管理员审核～")
        return redirect("/")  # 提交后返回首页

    # 6. GET请求：显示申请表单
    return render(request, "club/apply_club.html")
@login_required
def approve_club(request, club_id):
    club = Club.objects.get(id=club_id)
    if request.method == "POST":
        action = request.POST.get("action")
        if action == "pass":
            club.status = "approved"
            club.reject_reason = ""
            club.save()
            messages.success(request, f"社团「{club.name}」审核通过！")  # 新增提示
            return redirect("club:approve_list")
        elif action == "reject":
            # 后端验证驳回理由不能为空
            reject_reason = request.POST.get("reject_reason", "").strip()
            if not reject_reason:
                # 返回到审核页，提示错误
                return render(request, "club/approve_detail.html", {
                    "club": club,
                    "error": "驳回理由不能为空！"  
                })
            club.status = "rejected"
            club.reject_reason = reject_reason
            club.save()
            return redirect("club:approve_list")
    return render(request, "club/approve_detail.html", {"club": club})
  