
# from django.contrib import admin
# from .models import Club

# admin.site.register(Club)
from django.contrib import admin
from django.utils.html import format_html
from .models import Club

# 自定义Club的Admin管理类（加审核按钮）
@admin.register(Club)
class ClubAdmin(admin.ModelAdmin):
    # 1. 列表页显示核心字段（和前台审核列表一致）
    list_display = ('name', 'type', 'status', 'apply_time', 'advisor', 'audit_operation')
    # 2. 按审核状态筛选（方便快速找到待审核社团）
    list_filter = ('status',)
    # 3. 搜索功能（按社团名称搜索）
    search_fields = ('name',)
    # 4. 只读字段（申请时间不允许修改）
    readonly_fields = ('apply_time',)

    # 5. 自定义“审核操作”列（显示通过/驳回按钮）
    def audit_operation(self, obj):
        # 待审核社团才显示审核按钮
        if obj.status == 'pending':
            # 生成审核通过/驳回的链接（调用自定义Admin动作）
            pass_url = f"{obj.id}/audit/pass/"
            reject_url = f"{obj.id}/audit/reject/"
            return format_html(
                '<a href="{}" class="button btn-success btn-sm">通过</a> '
                '<a href="{}" class="button btn-danger btn-sm">驳回</a>',
                pass_url, reject_url
            )
        # 已审核的社团显示当前状态
        elif obj.status == 'approved':
            return format_html('<span class="text-success">已通过</span>')
        elif obj.status == 'rejected':
            return format_html('<span class="text-danger">已驳回</span>')
        return obj.status
    # 给自定义列起名字
    audit_operation.short_description = '审核操作'

    # 6. 自定义Admin动作（批量审核）
    actions = ['batch_pass', 'batch_reject']

    # 批量通过
    def batch_pass(self, request, queryset):
        queryset.update(status='approved', reject_reason='')
        self.message_user(request, "选中的社团已批量审核通过！")
    batch_pass.short_description = '批量审核通过'

    # 批量驳回
    def batch_reject(self, request, queryset):
        queryset.update(status='rejected', reject_reason='批量驳回（无具体理由）')
        self.message_user(request, "选中的社团已批量审核驳回！")
    batch_reject.short_description = '批量审核驳回'

    # 7. 配置Admin的URL（处理单个社团的审核请求）
    def get_urls(self):
        from django.urls import path
        # 新增审核通过/驳回的URL
        custom_urls = [
            path('<int:club_id>/audit/pass/', self.admin_site.admin_view(self.audit_pass), name='club_audit_pass'),
            path('<int:club_id>/audit/reject/', self.admin_site.admin_view(self.audit_reject), name='club_audit_reject'),
        ]
        # 合并默认URL和自定义URL
        return custom_urls + super().get_urls()

    # 8. 审核通过的逻辑
    def audit_pass(self, request, club_id):
        club = self.get_object(request, club_id)
        club.status = 'approved'
        club.reject_reason = ''
        club.save()
        self.message_user(request, f"社团「{club.name}」已审核通过！")
        # 跳回社团列表页
        return self.response_post_save_change(request, club)

    # 9. 审核驳回的逻辑（简单版，若需填理由可扩展）
    def audit_reject(self, request, club_id):
        club = self.get_object(request, club_id)
        club.status = 'rejected'
        club.reject_reason = 'Admin后台驳回（无具体理由）'  # 可扩展为弹窗填理由
        club.save()
        self.message_user(request, f"社团「{club.name}」已审核驳回！")
        return self.response_post_save_change(request, club)