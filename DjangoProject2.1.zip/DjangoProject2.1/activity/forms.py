from django import forms
from .models import ActivityApplication


class ActivityApplicationForm(forms.Form):
    title = forms.CharField(
        max_length=200,
        label='活动标题',
        widget=forms.TextInput(attrs={'class': 'form-control', 'placeholder': '请输入活动标题'})
    )

    club_name = forms.CharField(
        max_length=100,
        label='社团名称',
        widget=forms.TextInput(attrs={'class': 'form-control', 'placeholder': '请输入社团名称'})
    )

    contact_person = forms.CharField(
        max_length=50,
        label='负责人',
        widget=forms.TextInput(attrs={'class': 'form-control', 'placeholder': '请输入负责人姓名'})
    )

    contact_phone = forms.CharField(
        max_length=20,
        label='联系方式',
        widget=forms.TextInput(attrs={'class': 'form-control', 'placeholder': '请输入联系电话'})
    )

    activity_time = forms.DateTimeField(
        label='活动时间',
        widget=forms.DateTimeInput(attrs={'class': 'form-control', 'type': 'datetime-local'})
    )

    location = forms.CharField(
        max_length=200,
        label='活动地点',
        widget=forms.TextInput(attrs={'class': 'form-control', 'placeholder': '请输入活动地点'})
    )

    content = forms.CharField(
        label='活动内容',
        widget=forms.Textarea(attrs={'class': 'form-control', 'rows': 5, 'placeholder': '请详细描述活动内容'})
    )