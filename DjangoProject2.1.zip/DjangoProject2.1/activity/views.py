from django.shortcuts import render

# Create your views here.
from django.shortcuts import render, redirect, reverse
from django.http.response import JsonResponse
from django.contrib.auth.decorators import login_required
from django.views.decorators.http import require_http_methods
from .models import ActivityApplication
from .forms import ActivityApplicationForm
from django.contrib.admin.views.decorators import staff_member_required
from django.utils import timezone
from django.shortcuts import get_object_or_404

# 活动申请列表（我的申请）
@login_required
def my_applications(request):
    # 只显示当前用户的申请
    applications = ActivityApplication.objects.filter(applicant=request.user)
    return render(request, 'activity/my_applications.html', {
        'applications': applications
    })


# 提交活动申请
@login_required
@require_http_methods(['GET', 'POST'])
def apply_activity(request):
    if request.method == 'GET':
        # 显示申请表单
        form = ActivityApplicationForm()
        return render(request, 'activity/apply.html', {'form': form})
    else:
        # 处理表单提交
        form = ActivityApplicationForm(request.POST)
        if form.is_valid():
            # 创建申请记录
            application = ActivityApplication.objects.create(
                title=form.cleaned_data.get('title'),
                club_name=form.cleaned_data.get('club_name'),
                contact_person=form.cleaned_data.get('contact_person'),
                contact_phone=form.cleaned_data.get('contact_phone'),
                activity_time=form.cleaned_data.get('activity_time'),
                location=form.cleaned_data.get('location'),
                content=form.cleaned_data.get('content'),
                applicant=request.user,  # 自动关联当前用户
                status='pending'  # 默认状态为待审批
            )
            # 修改这里：返回更友好的成功信息
            return JsonResponse({
                'code': 200,
                'message': '申请已提交！请等待管理员审核。',
                'data': {
                    'application_id': application.id,
                    'title': application.title,
                    'apply_time': application.apply_time.strftime("%Y-%m-%d %H:%M:%S"),
                    'status': '待审批'
                }
            })
        else:
            # 表单验证失败
            return JsonResponse({
                'code': 400,
                'message': '表单填写有误，请检查后重新提交！'
            })


# 查看申请详情
@login_required
def application_detail(request, application_id):
    try:
        # 只能查看自己的申请
        application = ActivityApplication.objects.get(
            id=application_id,
            applicant=request.user
        )
    except ActivityApplication.DoesNotExist:
        application = None

    return render(request, 'activity/detail.html', {
        'application': application
    })


# ==================== 管理员审核功能 ====================

@staff_member_required
@login_required
def review_activity_list(request):
    """待审核活动列表 - 只有管理员可以访问"""
    # 获取所有待审核的活动申请，按申请时间倒序排列
    pending_activities = ActivityApplication.objects.filter(status='pending').order_by('-apply_time')

    # 获取审核统计信息
    stats = {
        'pending': ActivityApplication.objects.filter(status='pending').count(),
        'approved': ActivityApplication.objects.filter(status='approved').count(),
        'rejected': ActivityApplication.objects.filter(status='rejected').count(),
        'total': ActivityApplication.objects.count()
    }

    return render(request, 'activity/review_list.html', {
        'activities': pending_activities,
        'stats': stats
    })


@staff_member_required
@login_required
def review_activity_detail(request, application_id):
    """审核活动详情 - 只有管理员可以访问"""
    activity = get_object_or_404(ActivityApplication, id=application_id)

    if request.method == 'POST':
        action = request.POST.get('action')
        comment = request.POST.get('comment', '')

        if action == 'approve':
            activity.status = 'approved'
            message = '活动申请审核通过！'
        elif action == 'reject':
            activity.status = 'rejected'
            message = '活动申请审核拒绝！'
        else:
            return JsonResponse({'code': 400, 'message': '无效的操作！'})

        activity.reviewed_by = request.user
        activity.reviewed_at = timezone.now()
        activity.admin_comment = comment
        activity.save()

        # 返回审核后的活动信息
        return JsonResponse({
            'code': 200,
            'message': message,
            'data': {
                'activity_id': activity.id,
                'title': activity.title,
                'status': activity.get_status_display(),
                'reviewed_by': activity.reviewed_by.username if activity.reviewed_by else '未知',
                'reviewed_at': activity.reviewed_at.strftime("%Y-%m-%d %H:%M:%S") if activity.reviewed_at else '',
                'review_comment': activity.admin_comment
            }
        })

    # 获取申请人的其他活动统计
    user_activities_count = ActivityApplication.objects.filter(applicant=activity.applicant).count()
    user_pending_count = ActivityApplication.objects.filter(applicant=activity.applicant, status='pending').count()

    return render(request, 'activity/review_detail.html', {
        'activity': activity,
        'user_activities_count': user_activities_count,
        'user_pending_count': user_pending_count
    })


@staff_member_required
@login_required
def review_activity_history(request):
    """审核历史记录 - 只有管理员可以访问"""
    # 获取所有已审核的活动（包括通过和拒绝的）
    reviewed_activities = ActivityApplication.objects.filter(
        status__in=['approved', 'rejected']
    ).order_by('-reviewed_at')

    return render(request, 'activity/review_history.html', {
        'activities': reviewed_activities
    })