from django.db import models
from django.contrib.auth import get_user_model

User = get_user_model()


# 活动申请表
class ActivityApplication(models.Model):
    # 状态选择
    STATUS_CHOICES = [
        ('pending', '待审批'),
        ('approved', '已批准'),
        ('rejected', '已拒绝'),
    ]

    # 基本信息
    title = models.CharField(max_length=200, verbose_name='活动标题')
    club_name = models.CharField(max_length=100, verbose_name='社团名称')
    contact_person = models.CharField(max_length=50, verbose_name='负责人')
    contact_phone = models.CharField(max_length=20, verbose_name='联系方式')

    # 活动详情
    activity_time = models.DateTimeField(verbose_name='活动时间')
    location = models.CharField(max_length=200, verbose_name='活动地点')
    content = models.TextField(verbose_name='活动内容')

    # 申请信息
    applicant = models.ForeignKey(User, on_delete=models.CASCADE, verbose_name='申请人')
    apply_time = models.DateTimeField(auto_now_add=True, verbose_name='申请时间')

    # 审批信息 - 补充完整
    status = models.CharField(
        max_length=20,
        choices=STATUS_CHOICES,
        default='pending',
        verbose_name='审批状态'
    )
    # 新增审核人和审核时间字段
    reviewed_by = models.ForeignKey(
        User,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name='reviewed_activities',
        verbose_name='审核人'
    )
    reviewed_at = models.DateTimeField(null=True, blank=True, verbose_name='审核时间')
    admin_comment = models.TextField(blank=True, verbose_name='审批意见')

    def __str__(self):
        return f"{self.title} - {self.get_status_display()}"

    class Meta:
        verbose_name = '活动申请'
        verbose_name_plural = '活动申请'
        ordering = ['-apply_time']  # 按申请时间倒序排列