from django.contrib import admin
from .models import ActivityApplication


class ActivityApplicationAdmin(admin.ModelAdmin):
    list_display = ['title', 'club_name', 'applicant', 'apply_time', 'status', 'reviewed_by']
    list_filter = ['status', 'apply_time', 'club_name']
    search_fields = ['title', 'club_name', 'contact_person', 'applicant__username']
    readonly_fields = ['applicant', 'apply_time']  # 这些字段不可编辑
    list_per_page = 20

    # 自定义动作 - 批量审批
    actions = ['approve_applications', 'reject_applications']

    def approve_applications(self, request, queryset):
        for application in queryset:
            application.status = 'approved'
            application.reviewed_by = request.user
            application.reviewed_at = timezone.now()
            application.save()
        self.message_user(request, f"已批准 {queryset.count()} 个活动申请")

    approve_applications.short_description = "批准选中的申请"

    def reject_applications(self, request, queryset):
        for application in queryset:
            application.status = 'rejected'
            application.reviewed_by = request.user
            application.reviewed_at = timezone.now()
            application.save()
        self.message_user(request, f"已拒绝 {queryset.count()} 个活动申请")

    reject_applications.short_description = "拒绝选中的申请"


admin.site.register(ActivityApplication, ActivityApplicationAdmin)