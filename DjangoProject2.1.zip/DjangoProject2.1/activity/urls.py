from django.urls import path
from . import views

app_name = 'activity'

urlpatterns = [
    path('', views.my_applications, name='my_applications'),  # 我的申请列表
    path('apply/', views.apply_activity, name='apply'),  # 提交申请
    path('detail/<int:application_id>/', views.application_detail, name='detail'),  # 申请详情

 # ==================== 管理员审核功能 ====================
    path('review/', views.review_activity_list, name='review_list'),
    path('review/<int:application_id>/', views.review_activity_detail, name='review_detail'),
    path('review/history/', views.review_activity_history, name='review_history'),
]