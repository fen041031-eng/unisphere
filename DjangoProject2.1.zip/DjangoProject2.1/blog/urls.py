from django.urls import path
from . import views

app_name = 'blog'
urlpatterns = [
    # 首页 - 博客列表（只显示已审核的博客）
    path('', views.index, name='index'),

    # 博客详情页（只显示已审核的博客）
    path('blog/detail/<int:blog_id>', views.blog_detail, name='blog_detail'),

    # 发布博客（提交后为待审核状态）
    path('blog/pub', views.pub_blog, name='pub_blog'),

    # 发布评论
    path('blog/comment', views.pub_comment, name='pub_comment'),

    # 搜索功能（只搜索已审核的博客）
    path('search', views.search, name='search'),

    # ==================== 管理员审核功能 ====================

    # 待审核博客列表（只有管理员可以访问）
    path('review/', views.review_blog_list, name='review_list'),

    # 审核博客详情（只有管理员可以访问）
    path('review/<int:blog_id>/', views.review_blog_detail, name='review_detail'),
]