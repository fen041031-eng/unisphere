from django.shortcuts import render, redirect, reverse, get_object_or_404
from django.http.response import JsonResponse
from django.urls.base import reverse_lazy
from django.contrib.auth.decorators import login_required
from django.views.decorators.http import require_http_methods, require_POST, require_GET
from .models import BlogCategory, Blog, BlogComment
from django.db.models import Q
from .forms import PubBlogForm
from django.contrib.admin.views.decorators import staff_member_required
from django.utils import timezone
from activity.models import ActivityApplication
import json


# Create your views here.
def index(request):
    # 只显示已审核通过的博客
    blogs = Blog.objects.filter(status='approved').all()
    approved_activities = ActivityApplication.objects.filter(
        status='approved'
    ).order_by('-activity_time')  # 按活动时间倒序，最新的在前面

    return render(request, 'index.html', {
        "blogs": blogs,
        "activities": approved_activities  # 新增：传递活动数据
    })


def blog_detail(request, blog_id):
    # 只允许查看已审核的博客详情
    try:
        blog = Blog.objects.get(pk=blog_id, status='approved')
    except Exception as e:
        blog = None
    return render(request, 'blog_detail.html', context={'blog': blog})


@require_http_methods(['GET', 'POST'])
@login_required()
def pub_blog(request):
    if request.method == 'GET':
        categories = BlogCategory.objects.all()
        return render(request, 'pub_blog.html', context={"categories": categories})
    else:
        form = PubBlogForm(request.POST)
        if form.is_valid():
            title = form.cleaned_data.get('title')
            content = form.cleaned_data.get('content')
            category_id = form.cleaned_data.get('category')

            # 创建博客，状态为待审核
            blog = Blog.objects.create(
                title=title,
                content=content,
                category_id=category_id,
                author=request.user,
                status='pending'  # 设置为待审核状态
            )

            # 返回更详细的信息
            return JsonResponse({
                "code": 200,
                "message": "博客提交成功，等待管理员审核！",
                "data": {
                    "blog_id": blog.id,
                    "title": blog.title,
                    "status": blog.get_status_display(),  # 显示中文状态
                    "submit_time": blog.pub_time.strftime("%Y-%m-%d %H:%M:%S"),
                    "next_step": "请等待管理员审核，通过后将在首页显示。",
                    "category": blog.category.name if blog.category else "未分类"
                }
            })
        else:
            # 获取表单错误信息
            errors = {}
            for field, error_list in form.errors.items():
                errors[field] = [error for error in error_list]

            return JsonResponse({
                'code': 400,
                "message": "表单验证失败，请检查输入！",
                "errors": errors
            })


@require_POST
@login_required()
def pub_comment(request):
    blog_id = request.POST.get('blog_id')
    content = request.POST.get('content')

    # 确保博客存在且已审核
    try:
        blog = Blog.objects.get(id=blog_id, status='approved')
        BlogComment.objects.create(content=content, blog_id=blog_id, author=request.user)
        return redirect(reverse("blog:blog_detail", kwargs={'blog_id': blog_id}))
    except Blog.DoesNotExist:
        # 如果博客不存在或未审核，返回错误
        return JsonResponse({
            'code': 404,
            'message': '博客不存在或未通过审核'
        })


@require_GET
def search(request):
    # /search?q=xxx
    q = request.GET.get('q')

    if not q:
        # 如果搜索词为空，返回所有已审核博客
        blogs = Blog.objects.filter(status='approved').all()
    else:
        # 从已审核的博客的标题和内容中查找含有q关键字的博客
        blogs = Blog.objects.filter(
            Q(title__icontains=q) | Q(content__icontains=q),
            status='approved'
        ).all()

    return render(request, 'index.html', context={
        "blogs": blogs,
        "search_query": q
    })


# 管理员审核功能
@staff_member_required
@login_required
def review_blog_list(request):
    """待审核博客列表 - 只有管理员可以访问"""
    # 获取所有待审核的博客，按提交时间倒序排列
    pending_blogs = Blog.objects.filter(status='pending').order_by('-pub_time')

    # 获取审核统计信息
    stats = {
        'pending': Blog.objects.filter(status='pending').count(),
        'approved': Blog.objects.filter(status='approved').count(),
        'rejected': Blog.objects.filter(status='rejected').count(),
        'total': Blog.objects.count()
    }

    return render(request, 'blog/review_list.html', {
        'blogs': pending_blogs,
        'stats': stats
    })


@staff_member_required
@login_required
def review_blog_detail(request, blog_id):
    """审核博客详情 - 只有管理员可以访问"""
    blog = get_object_or_404(Blog, id=blog_id)

    if request.method == 'POST':
        action = request.POST.get('action')
        comment = request.POST.get('comment', '')

        if action == 'approve':
            blog.status = 'approved'
            message = '博客审核通过！'
        elif action == 'reject':
            blog.status = 'rejected'
            message = '博客审核拒绝！'
        else:
            return JsonResponse({'code': 400, 'message': '无效的操作！'})

        blog.reviewed_by = request.user
        blog.reviewed_at = timezone.now()
        blog.review_comment = comment
        blog.save()

        # 返回审核后的博客信息
        return JsonResponse({
            'code': 200,
            'message': message,
            'data': {
                'blog_id': blog.id,
                'title': blog.title,
                'status': blog.get_status_display(),
                'reviewed_by': blog.reviewed_by.username if blog.reviewed_by else '未知',
                'reviewed_at': blog.reviewed_at.strftime("%Y-%m-%d %H:%M:%S") if blog.reviewed_at else '',
                'review_comment': blog.review_comment
            }
        })

    # 获取相关统计信息
    user_blogs_count = Blog.objects.filter(author=blog.author).count()
    user_pending_count = Blog.objects.filter(author=blog.author, status='pending').count()

    return render(request, 'blog/review_detail.html', {
        'blog': blog,
        'user_blogs_count': user_blogs_count,
        'user_pending_count': user_pending_count
    })


@staff_member_required
@login_required
def review_history(request):
    """审核历史记录 - 只有管理员可以访问"""
    # 获取所有已审核的博客（包括通过和拒绝的）
    reviewed_blogs = Blog.objects.filter(
        status__in=['approved', 'rejected']
    ).order_by('-reviewed_at')

    return render(request, 'blog/review_history.html', {
        'blogs': reviewed_blogs
    })